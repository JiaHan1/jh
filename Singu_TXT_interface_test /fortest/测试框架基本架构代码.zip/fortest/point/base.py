class BasePoint:

    NAME = '基础断言点'
