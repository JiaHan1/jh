from behavior.base import PipelineBehavior


class CheckRollbackBehavior(PipelineBehavior):
    Name = '质检打回'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
