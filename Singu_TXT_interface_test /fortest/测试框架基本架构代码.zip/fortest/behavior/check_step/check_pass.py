from behavior.base import PipelineBehavior


class CheckPassBehavior(PipelineBehavior):
    Name = '质检通过'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
