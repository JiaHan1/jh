from behavior.base import PipelineBehavior


class TrainingBehavior(PipelineBehavior):
    Name = '模型训练'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
