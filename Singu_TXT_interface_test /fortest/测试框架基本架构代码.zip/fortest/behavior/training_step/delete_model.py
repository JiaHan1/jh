from behavior.base import OtherBehavior


class DeleteTrainingBatchBehavior(OtherBehavior):

    Name = '删除批次模型'
    IS_END = True

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
