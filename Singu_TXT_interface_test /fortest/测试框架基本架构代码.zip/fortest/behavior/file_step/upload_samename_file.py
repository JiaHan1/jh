from behavior.base import OtherBehavior


class UploadSameNameFileBehavior(OtherBehavior):

    Name = '上传同名文件'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
