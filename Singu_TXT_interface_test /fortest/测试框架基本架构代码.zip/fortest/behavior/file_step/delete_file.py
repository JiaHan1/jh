from behavior.base import OtherBehavior


class DeleteFileBehavior(OtherBehavior):

    Name = '删除文件'
    IS_END = True

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
