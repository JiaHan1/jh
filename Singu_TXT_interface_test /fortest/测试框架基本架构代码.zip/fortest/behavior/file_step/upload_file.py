from behavior.base import PipelineBehavior


class UploadFileBehavior(PipelineBehavior):
    Name = '上传文件'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
