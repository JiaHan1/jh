from behavior.base import OtherBehavior


class ReClusterBehavior(OtherBehavior):

    Name = '更换聚类模型并重新聚类'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
