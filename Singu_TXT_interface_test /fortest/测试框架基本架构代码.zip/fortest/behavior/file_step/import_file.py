from behavior.base import PipelineBehavior


class ImportFileBehavior(PipelineBehavior):
    Name = '导入文件'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
