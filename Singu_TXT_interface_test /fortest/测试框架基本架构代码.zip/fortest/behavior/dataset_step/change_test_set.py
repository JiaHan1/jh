from behavior.base import OtherBehavior


class ChangeTestSetBehavior(OtherBehavior):

    Name = '变更测试集'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
