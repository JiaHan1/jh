from behavior.base import OtherBehavior


class ChangeTrainingSetBehavior(OtherBehavior):

    Name = '变更训练集'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
