from behavior.base import OtherBehavior


class ChangeSchemaBehavior(OtherBehavior):

    Name = '修改字段'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
