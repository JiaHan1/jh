from behavior.base import OtherBehavior


class ReClassificationBehavior(OtherBehavior):

    Name = '重新选分类'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
