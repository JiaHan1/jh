from behavior.base import OtherBehavior


class ChangeClassificationBehavior(OtherBehavior):

    Name = '修改分类'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
