from behavior.base import PipelineBehavior


class RejectBehavior(PipelineBehavior):
    Name = '驳回'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
