from behavior.base import PipelineBehavior


class LabelBehavior(PipelineBehavior):
    Name = '标注'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
