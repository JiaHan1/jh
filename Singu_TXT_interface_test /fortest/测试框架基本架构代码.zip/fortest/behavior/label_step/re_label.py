from behavior.base import OtherBehavior


class ReLabelBehavior(OtherBehavior):

    Name = '重新标注'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
