from behavior.base import OtherBehavior


class ReprocessBehavior(OtherBehavior):

    Name = '重新预处理'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
