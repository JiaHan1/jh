from behavior.base import OtherBehavior


class ChangeConfigBehavior(OtherBehavior):

    Name = '修改配置'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass
