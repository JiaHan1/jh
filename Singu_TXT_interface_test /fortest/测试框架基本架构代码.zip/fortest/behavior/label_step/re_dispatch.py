from behavior.base import OtherBehavior


class ReDispatchBehavior(OtherBehavior):

    Name = '重新分发'

    def real_do_api(self):
        pass

    def local_behavior(self):
        pass