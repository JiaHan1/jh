class RequestData:

    def __init__(self):
        pass
